-- This Source Code Form is subject to the terms of the bCDDL, v. 1.1.
-- If a copy of the bCDDL was not distributed with this
-- file, You can obtain one at http://beamng.com/bCDDL-1.1.txt

local M = {}

local function onInit()
	electrics.values['lifter'] = 0
end

local function reset()
	onInit()
end

local function updateGFX(dt)
	if electrics.values['turnsignal'] == 0 then
		electrics.values['lifter'] = 0
	else
		electrics.values['lifter'] = math.min(1, math.max(0, electrics.values['lifter'] + electrics.values['turnsignal'] * dt * 0.03))
	end
end

-- public interface
M.onInit    = onInit
M.reset     = reset
M.updateGFX = updateGFX

return M