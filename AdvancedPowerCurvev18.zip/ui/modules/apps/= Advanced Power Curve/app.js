angular.module('beamng.apps')
.directive('powerviewer', ['$log', 'CanvasShortcuts',
function ($log, CanvasShortcuts) {
  return {
    template: `
      <div style="width: 100%; height: 100%; pointer-events: none; display: flex; padding: 0; box-sizing: border-box;" 
           ng-style="getContainerStyle()">

        <div ng-show="appMode === 'launcher'" style="pointer-events: auto; padding: 6px; background: rgba(0,0,0,0.8); border-radius: 4px; border: 1px solid #444; display: flex; gap: 6px;">
            <div ng-click="setAppMode('full')" 
                 ng-style="{'background': uiAccentColor, 'border': '1px solid ' + uiAccentColor, 'color': '#000'}" 
                 style="font-size: 11px; font-weight: bold; padding: 4px 12px; cursor: pointer; border-radius: 2px;">
                 POWER
            </div>
        </div>

        <div ng-show="appMode === 'full'" 
             style="position: relative; pointer-events: auto; display: flex; flex-direction: column; border-radius: 6px; font-family: monospace; border: 1px solid #444; overflow: hidden;" 
             ng-style="{'background-color': 'rgba(0,0,0,' + uiOpacity + ')', 'width': appWidth + 'px', 'height': appHeight + 'px', 'border-color': 'rgba(68,68,68,' + valuesOpacity + ')'}">

          <div ng-if="showPeakInfo" 
               style="position: absolute; top: 2px; left: 4px; padding: 4px 8px; pointer-events: none; border: 1px solid; z-index: 5; background: rgba(0,0,0,0.3); border-radius: 4px;" 
               ng-style="{'border-color': getAccentRgba(valuesOpacity)}">
               
                <!-- POWER LINE -->
                <div ng-style="{'font-size': sizePeak + 'px', 'color': colorPower, 'opacity': powerOpacity}" style="font-weight: bold; line-height: 1.2;">
                  {{ formatNum(convertPower(absMaxPower)) }}{{ unitPower }} @ {{ formatNum(peakPowerRpm) }}rpm 
                  
                  <!-- 3-Way Toggle: Diff / NA / Off -->
                  <span ng-if="peakDiffMode !== 'off' && diffPower > 0">
                    <span ng-if="peakDiffMode === 'diff'" style="font-style: italic; opacity: 0.8; font-size: 0.8em; font-weight: normal; margin-left: 4px;">
                        (+{{ formatNum(convertPower(diffPower)) }}{{ unitPower }})
                    </span>
                    <span ng-if="peakDiffMode === 'na'" style="font-style: italic; opacity: 0.8; font-size: 0.8em; font-weight: normal; margin-left: 4px;">
                        (NA: {{ formatNum(convertPower(naMaxPower)) }}{{ unitPower }})
                    </span>
                  </span>
                </div>

                <div ng-if="unitPowerSec !== 'off'" ng-style="{'font-size': (sizePeak * 0.85) + 'px', 'color': colorPower, 'opacity': powerOpacity * 0.75}" style="font-weight: bold; line-height: 1.0; margin-bottom: 4px;">
                   {{ formatNum(convertRawPower(absMaxPower, unitPowerSec)) }}{{ unitPowerSec }}
                </div>

                <!-- TORQUE LINE -->
                <div ng-style="{'font-size': sizePeak + 'px', 'color': colorTorque, 'opacity': powerOpacity}" style="font-weight: bold; line-height: 1.2;">
                  {{ formatNum(convertTorque(absMaxTorque)) }}{{ unitTorque }} @ {{ formatNum(peakTorqueRpm) }}rpm
                  
                  <!-- 3-Way Toggle: Diff / NA / Off -->
                  <span ng-if="peakDiffMode !== 'off' && diffTorque > 0">
                    <span ng-if="peakDiffMode === 'diff'" style="font-style: italic; opacity: 0.8; font-size: 0.8em; font-weight: normal; margin-left: 4px;">
                        (+{{ formatNum(convertTorque(diffTorque)) }}{{ unitTorque }})
                    </span>
                    <span ng-if="peakDiffMode === 'na'" style="font-style: italic; opacity: 0.8; font-size: 0.8em; font-weight: normal; margin-left: 4px;">
                        (NA: {{ formatNum(convertTorque(naMaxTorque)) }}{{ unitTorque }})
                    </span>
                  </span>
                </div>
                
                <div ng-if="unitTorqueSec !== 'off'" ng-style="{'font-size': (sizePeak * 0.85) + 'px', 'color': colorTorque, 'opacity': powerOpacity * 0.75}" style="font-weight: bold; line-height: 1.0;">
                   {{ formatNum(convertRawTorque(absMaxTorque, unitTorqueSec)) }}{{ unitTorqueSec }}
                </div>
          </div>

          <div style="display: flex; justify-content: flex-end; align-items: flex-start; padding: 0; min-height: 26px;"
               ng-style="{'border-top': '2px solid ' + getAccentRgba(valuesOpacity)}">
            
            <div ng-mousedown="startHoldBtn('clear')" ng-mouseup="endHoldBtn()" ng-mouseleave="endHoldBtn()"
                 ng-style="{'background': ghostData ? '#444' : '#222', 'color': ghostData ? '#fff' : '#555', 'cursor': ghostData ? 'pointer' : 'default', 'border-color': ghostData ? '#fff' : '#444'}"
                 style="position: relative; margin: 2px 4px; padding: 0 12px; height: 16px; border-radius: 0 0 4px 4px; border: 1px solid; border-top: none; display: flex; align-items: center; font-size: 9px; font-weight: bold; z-index: 10; overflow: hidden;">
              <div ng-if="activeBtn === 'clear'" ng-style="{'width': holdProgress + '%', 'background': 'rgba(255,0,0,0.5)'}" style="position: absolute; left: 0; top: 0; height: 100%;"></div>
              <span style="position: relative; z-index: 2;">CLEAR</span>
            </div>

            <div ng-mousedown="startHoldBtn('hold')" ng-mouseup="endHoldBtn()" ng-mouseleave="endHoldBtn()"
                 ng-style="{'background': ghostData ? uiAccentColor : 'rgba(0,0,0,0)', 'color': ghostData ? '#000' : uiAccentColor, 'border-color': ghostData ? '#fff' : uiAccentColor, 'opacity': ghostData ? 1 : 0.6}"
                 style="position: relative; margin: 2px 4px; padding: 0 12px; height: 16px; cursor: pointer; border-radius: 0 0 4px 4px; border: 1px solid; border-top: none; display: flex; align-items: center; font-size: 9px; font-weight: bold; z-index: 10; overflow: hidden; transition: opacity 0.2s;">
              <div ng-if="activeBtn === 'hold'" style="position: absolute; left: 0; top: 0; height: 100%; background: rgba(255,255,255,0.3);" ng-style="{'width': holdProgress + '%'}"></div>
              <span style="position: relative; z-index: 2;">HOLD</span>
            </div>

            <div ng-click="showSettings = !showSettings" style="margin: 2px 4px; padding: 0 12px; height: 22px; background: #444; color: #fff; cursor: pointer; border-radius: 0 0 4px 4px; border: 1px solid #666; border-top: none; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; z-index: 10;">
              SETTINGS
            </div>

            <div ng-click="setAppMode('launcher')" 
                 style="margin: 2px 4px; width: 22px; height: 22px; background: #aa0000; color: #fff; cursor: pointer; border-radius: 2px; border: 1px solid #ff4444; display: flex; align-items: center; justify-content: center; z-index: 10;">
                 <svg style="width:14px;height:14px;" viewBox="0 0 24 24"><path fill="currentColor" d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg>
            </div>

          </div>

          <div style="flex: 1; position: relative; margin: 0; overflow: hidden;">
            <canvas style="position: absolute; top: 0; left: 0" width="50" height="50"></canvas>
            <canvas style="position: absolute; top: 0; left: 0" width="50" height="50"></canvas>
          </div>

          <div ng-if="showSettings" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 600px; background: rgba(0,0,0,0.98); z-index: 10000; border-radius: 8px; display: flex; flex-direction: column; color: white; box-shadow: 0 0 50px rgba(0,0,0,0.8);"
               ng-style="{'border': '2px solid ' + uiAccentColor}">
               
               <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #555; background: rgba(0,0,0,0.5); padding: 10px; border-radius: 8px 8px 0 0;">
                  <span ng-style="{'color': uiAccentColor}" style="font-weight: bold; font-size: 16px; text-transform: uppercase;">ADVANCED POWER CURVE SETTINGS</span>
                  <div ng-click="$parent.showSettings = false" style="background: #ff4444; color: white; cursor: pointer; font-weight: bold; font-size: 12px; padding: 6px 12px; border-radius: 3px;">CLOSE</div>
               </div>

               <div style="padding: 15px; display: flex; flex-direction: column; gap: 12px; max-height: 80vh; overflow-y: auto;">

                  <div style="display: flex; gap: 10px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px; align-items: center; flex-wrap: wrap;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold; width: 60px;">OPTIONS</span>
                      <div ng-click="toggleRpmLine()" ng-style="getBtnStyle(showRpmLine !== 'off')">RPM: {{ showRpmLine.toUpperCase() }}</div>
                      <div ng-click="togglePeakLines()" ng-style="getBtnStyle(showPeakLines)">PEAK LINES</div>
                      <div ng-click="toggleGhostPeakLines()" ng-style="getBtnStyle(showGhostPeakLines)">GHOST LINES</div>
                      <div ng-click="toggleSubTicks()" ng-style="getBtnStyle(showSubTicks)">SUB VALUES</div>
                  </div>

                  <div style="display: flex; gap: 10px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px; align-items: center; flex-wrap: wrap;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold; width: 60px;">PEAK INFO</span>
                      <div ng-click="togglePeakInfo()" ng-style="getBtnStyle(showPeakInfo)">PEAK INFO</div>
                      <div ng-click="togglePeakDiffMode()" ng-style="getBtnStyle(peakDiffMode !== 'off')">DIFF: {{ peakDiffMode.toUpperCase() }}</div>
                  </div>

                  <div style="display: flex; gap: 10px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px; align-items: center;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold; width: 60px;">UNITS</span>
                      <div style="display: flex; gap: 4px; border: 1px solid #555; padding: 3px; border-radius: 3px;">
                          <div ng-click="setUnit('unitPower', 'hp')" ng-style="getBtnStyle(unitPower=='hp')">HP</div>
                          <div ng-click="setUnit('unitPower', 'kw')" ng-style="getBtnStyle(unitPower=='kw')">KW</div>
                          <div ng-click="setUnit('unitPower', 'ps')" ng-style="getBtnStyle(unitPower=='ps')">PS</div>
                      </div>
                      <div style="display: flex; gap: 4px; border: 1px solid #555; padding: 3px; border-radius: 3px;">
                          <div ng-click="setUnit('unitTorque', 'Nm')" ng-style="getBtnStyle(unitTorque=='Nm')">NM</div>
                          <div ng-click="setUnit('unitTorque', 'lb-ft')" ng-style="getBtnStyle(unitTorque=='lb-ft')">LB-FT</div>
                          <div ng-click="setUnit('unitTorque', 'kg-m')" ng-style="getBtnStyle(unitTorque=='kg-m')">KG-M</div>
                      </div>
                  </div>

                  <div style="display: flex; gap: 10px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px; align-items: center;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold; width: 60px;">SECONDARY UNITS</span>
                      
                      <div style="display: flex; gap: 4px; border: 1px solid #555; padding: 3px; border-radius: 3px;">
                          <div ng-click="setSecUnit('unitPowerSec', 'off')" ng-style="getBtnStyle(unitPowerSec=='off')">OFF</div>
                          <div ng-click="setSecUnit('unitPowerSec', 'hp')" ng-style="getBtnStyle(unitPowerSec=='hp')">HP</div>
                          <div ng-click="setSecUnit('unitPowerSec', 'kw')" ng-style="getBtnStyle(unitPowerSec=='kw')">KW</div>
                          <div ng-click="setSecUnit('unitPowerSec', 'ps')" ng-style="getBtnStyle(unitPowerSec=='ps')">PS</div>
                      </div>

                      <div style="display: flex; gap: 4px; border: 1px solid #555; padding: 3px; border-radius: 3px;">
                          <div ng-click="setSecUnit('unitTorqueSec', 'off')" ng-style="getBtnStyle(unitTorqueSec=='off')">OFF</div>
                          <div ng-click="setSecUnit('unitTorqueSec', 'Nm')" ng-style="getBtnStyle(unitTorqueSec=='Nm')">NM</div>
                          <div ng-click="setSecUnit('unitTorqueSec', 'lb-ft')" ng-style="getBtnStyle(unitTorqueSec=='lb-ft')">LB-FT</div>
                          <div ng-click="setSecUnit('unitTorqueSec', 'kg-m')" ng-style="getBtnStyle(unitTorqueSec=='kg-m')">KG-M</div>
                      </div>
                  </div>

                  <div style="display: flex; flex-direction: column; gap: 8px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold;">SIZES</span>
                      <div style="display: flex; gap: 10px;">
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                            <div ng-click="adjText('peak', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                            <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 100px;">PEAK INFO {{ sizePeak }}</div>
                            <div ng-click="adjText('peak', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                            <div ng-click="adjText('main', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                            <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 100px;">GRAPH TEXT {{ sizeMain }}</div>
                            <div ng-click="adjText('main', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>
                      <div style="display: flex; gap: 10px;">
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                            <div ng-click="adjSize('w', -50)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                            <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 80px;">WIDTH {{ appWidth }}</div>
                            <div ng-click="adjSize('w', 50)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                            <div ng-click="adjSize('h', -50)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                            <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 80px;">HEIGHT {{ appHeight }}</div>
                            <div ng-click="adjSize('h', 50)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>
                  </div>

                  <div style="display: flex; flex-direction: column; gap: 8px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold;">COLOURS</span>
                      
                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">{{ unitPower.toUpperCase() }} CURVE</span>
                          <div style="display: flex; gap: 6px;">
                               <div ng-repeat="c in colorOptions" ng-click="setColor('hp', c)" ng-style="{'background': c, 'border': colorPower === c ? '2px solid #fff' : '1px solid #555'}" style="width: 18px; height: 18px; border-radius: 50%; cursor: pointer;"></div>
                          </div>
                      </div>
                      
                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">{{ unitTorque.toUpperCase() }} CURVE</span>
                          <div style="display: flex; gap: 6px;">
                               <div ng-repeat="c in colorOptions" ng-click="setColor('trq', c)" ng-style="{'background': c, 'border': colorTorque === c ? '2px solid #fff' : '1px solid #555'}" style="width: 18px; height: 18px; border-radius: 50%; cursor: pointer;"></div>
                          </div>
                      </div>

                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">UI ACCENT</span>
                          <div style="display: flex; gap: 6px;">
                               <div ng-repeat="c in colorOptions" ng-click="setColor('accent', c)" ng-style="{'background': c, 'border': uiAccentColor === c ? '2px solid #fff' : '1px solid #555'}" style="width: 18px; height: 18px; border-radius: 50%; cursor: pointer;"></div>
                          </div>
                      </div>
                  </div>

                  <div style="display: flex; flex-direction: column; gap: 8px; background: rgba(255,255,255,0.05); padding: 10px; border-radius: 4px;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold;">OPACITIES</span>

                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">HOLD CURVES</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('ghostOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(ghostOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('ghostOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>

                      <div ng-if="hasDashedLines" style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">DASHED CURVES</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('dashedOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(dashedOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('dashedOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>
                      
                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">GRAPH SCALE VALUES</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('valuesOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(valuesOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('valuesOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>
                      
                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">POWER CURVES + PEAK INFO</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('powerOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(powerOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('powerOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>

                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">PEAK LINES</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('lineOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(lineOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('lineOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>

                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">BACKGROUND</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('uiOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(uiOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('uiOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>

                      <div style="display: flex; align-items: center; gap: 10px;">
                          <span style="font-size: 11px; color: #aaa; width: 100px;">GRID LINES</span>
                          <div style="display: flex; background: rgba(255,255,255,0.1); border: 1px solid #444; border-radius: 3px; height: 24px;">
                              <div ng-click="adjOpacity('gridOpacity', -1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">-</div>
                              <div style="padding: 0 10px; font-size: 11px; border-left: 1px solid #444; border-right: 1px solid #444; text-align: center; line-height: 24px; min-width: 60px;">{{ Math.round(gridOpacity * 100) }}%</div>
                              <div ng-click="adjOpacity('gridOpacity', 1)" style="padding: 0 10px; cursor: pointer; font-weight:bold;" ng-style="{'color': uiAccentColor}">+</div>
                          </div>
                      </div>

                  </div>

                  <div style="display: flex; flex-direction: column; gap: 6px; padding: 10px; background: rgba(255,255,255,0.05); border-radius: 4px;">
                      <span style="font-size: 12px; color: #fff; font-weight: bold;">LAUNCHER POSITION</span>
                      <div style="display: flex; align-items: center; gap: 6px;">
                          <div style="width: 40px; font-size: 10px; color: #aaa; font-weight: bold;">TOP:</div>
                          <div ng-click="setLaunchPos('top-left')" ng-style="getBtnStyle(launcherPos === 'top-left')">L</div>
                          <div ng-click="setLaunchPos('top-center')" ng-style="getBtnStyle(launcherPos === 'top-center')">C</div>
                          <div ng-click="setLaunchPos('top-right')" ng-style="getBtnStyle(launcherPos === 'top-right')">R</div>
                      </div>
                      <div style="display: flex; align-items: center; gap: 6px;">
                          <div style="width: 40px; font-size: 10px; color: #aaa; font-weight: bold;">BTM:</div>
                          <div ng-click="setLaunchPos('bottom-left')" ng-style="getBtnStyle(launcherPos === 'bottom-left')">L</div>
                          <div ng-click="setLaunchPos('bottom-center')" ng-style="getBtnStyle(launcherPos === 'bottom-center')">C</div>
                          <div ng-click="setLaunchPos('bottom-right')" ng-style="getBtnStyle(launcherPos === 'bottom-right')">R</div>
                      </div>
                  </div>

               </div>
          </div>
        </div>
      </div>`,
    replace: true,
    restrict: 'EA',
    link: function (scope, element, attrs) {
      // 0. POINTER EVENTS & POWER LOGIC
      element.parent().css({pointerEvents: 'none'});
      
      scope.appMode = localStorage.getItem('powerviewer_appMode') || 'launcher';
      scope.launcherPos = localStorage.getItem('powerviewer_launcherPos') || 'bottom-center';
      
      scope.setAppMode = (mode) => {
          scope.appMode = mode;
          localStorage.setItem('powerviewer_appMode', mode);
          if(mode === 'full') setTimeout(scope.graph, 50); 
      }

      scope.setLaunchPos = (pos) => {
          scope.launcherPos = pos;
          localStorage.setItem('powerviewer_launcherPos', pos);
      }

      scope.getContainerStyle = () => {
          let s = { 
              justifyContent: 'center', 
              alignItems: 'center'
          };
          
          let parts = scope.launcherPos.split('-');
          
          if (parts[0] === 'top') s.alignItems = 'flex-start';
          else s.alignItems = 'flex-end';
          
          if (parts[1] === 'left') s.justifyContent = 'flex-start';
          else if (parts[1] === 'right') s.justifyContent = 'flex-end';
          else s.justifyContent = 'center';
          
          return s;
      }

      var streamsList = ['engineInfo']
      StreamsManager.add(streamsList)
      scope.$on('$destroy', function () {
        StreamsManager.remove(streamsList)
      })

      // 1. PERSISTENT SETTINGS
      scope.config = {}
      scope.showSettings = false
      scope.Math = window.Math 
      scope.holdTimer = null
      scope.holdProgress = 0
      scope.ghostData = null 
      scope.hasDashedLines = false
      
      scope.appMode = localStorage.getItem('powerviewer_appMode') || 'full' 
      
      scope.launcherPos = localStorage.getItem('powerviewer_launcherPos') || 'top-right' 

      scope.unitPowerSec = localStorage.getItem('powerviewer_unitPowerSec') || 'off'
      scope.unitTorqueSec = localStorage.getItem('powerviewer_unitTorqueSec') || 'off'
      
      scope.appWidth = parseInt(localStorage.getItem('powerviewer_width')) || 550
      scope.appHeight = parseInt(localStorage.getItem('powerviewer_height')) || 200
      scope.sizePeak = Math.max(10, parseInt(localStorage.getItem('powerviewer_sizePeak')) || 14)
      scope.sizeMain = parseInt(localStorage.getItem('powerviewer_sizeMain')) || 13
      
      scope.showPeakInfo = localStorage.getItem('powerviewer_showPeakInfo') !== 'false' // Default On
      
      // RPM LINE 3-WAY TOGGLE MIGRATION
      var storedRpm = localStorage.getItem('powerviewer_showRpmLine');
      if (storedRpm === 'true') storedRpm = 'faded'; // Legacy support
      if (storedRpm === 'false') storedRpm = 'off';  // Legacy support
      scope.showRpmLine = storedRpm || 'faded'; 

      // PEAK DIFF 3-WAY TOGGLE
      scope.peakDiffMode = localStorage.getItem('powerviewer_peakDiffMode') || 'diff';

      scope.showPeakLines = localStorage.getItem('powerviewer_showPeakLines') !== 'false' // Default On
      scope.showGhostPeakLines = localStorage.getItem('powerviewer_showGhostPeakLines') !== 'false' // Default On
      scope.showSubTicks = localStorage.getItem('powerviewer_showSubTicks') === 'true'    // Default Off
      
      scope.unitPower = localStorage.getItem('powerviewer_unitPower') || 'hp'
      scope.unitTorque = localStorage.getItem('powerviewer_unitTorque') || 'Nm'

      // Colours
      scope.uiAccentColor = localStorage.getItem('powerviewer_uiAccentColor') || '#ffaa00' 
      scope.colorPower = localStorage.getItem('powerviewer_colorPower') || '#ffffff' 
      scope.colorTorque = localStorage.getItem('powerviewer_colorTorque') || '#ff4444' 
      
      // Opacities
      scope.uiOpacity = parseFloat(localStorage.getItem('powerviewer_uiOpacity')) || 0.70
      scope.gridOpacity = parseFloat(localStorage.getItem('powerviewer_gridOpacity')) || 0.25
      scope.ghostOpacity = parseFloat(localStorage.getItem('powerviewer_ghostOpacity')) || 0.55
      scope.dashedOpacity = parseFloat(localStorage.getItem('powerviewer_dashedOpacity')) || 0.40
      scope.valuesOpacity = parseFloat(localStorage.getItem('powerviewer_valuesOpacity')) || 0.75
      scope.powerOpacity = parseFloat(localStorage.getItem('powerviewer_powerOpacity')) || 1.0
      scope.lineOpacity = parseFloat(localStorage.getItem('powerviewer_lineOpacity')) || 0.40
      
      scope.colorOptions = ['#ffaa00', '#00ffff', '#ff4444', '#00ff00', '#df80ff', '#ffffff', '#ffff00']

      // 2. HELPER FUNCTIONS
      scope.getAccentRgba = (alpha) => {
        let c = scope.uiAccentColor.substring(1)
        if(c.length === 3) c = c[0]+c[0]+c[1]+c[1]+c[2]+c[2]
        let bigint = parseInt(c, 16)
        let r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')'
      }

      scope.formatNum = (val) => Math.round(val).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
      
      // Generic Raw Converters
      scope.convertRawPower = (val, targetUnit) => {
        if (targetUnit === 'kw') return val * 0.7355
        if (targetUnit === 'hp') return val * 0.9863
        return val // Default is PS
      }

      scope.convertRawTorque = (val, targetUnit) => {
        if (targetUnit === 'lb-ft') return val * 0.73756
        if (targetUnit === 'kg-m') return val * 0.10197 
        return val // Default is Nm
      }

      scope.convertPower = (val) => scope.convertRawPower(val, scope.unitPower)
      scope.convertTorque = (val) => scope.convertRawTorque(val, scope.unitTorque)

      scope.setSecUnit = (type, val) => {
        scope[type] = val
        localStorage.setItem('powerviewer_' + type, val)
      }

      scope.adjSize = (dim, amt) => {
        if (dim === 'w') scope.appWidth = Math.max(300, scope.appWidth + amt)
        if (dim === 'h') scope.appHeight = Math.max(100, scope.appHeight + amt)
        localStorage.setItem('powerviewer_width', scope.appWidth)
        localStorage.setItem('powerviewer_height', scope.appHeight)
        scope.graph()
      }

      scope.adjText = (target, amt) => {
        if (target === 'peak') scope.sizePeak = Math.max(10, scope.sizePeak + amt)
        else scope.sizeMain = Math.max(8, scope.sizeMain + amt)
        localStorage.setItem('powerviewer_sizePeak', scope.sizePeak)
        localStorage.setItem('powerviewer_sizeMain', scope.sizeMain)
        scope.graph()
      }

      scope.adjOpacity = (target, dir) => {
        let val = scope[target] + (dir * 0.05)
        val = Math.max(0.0, Math.min(1.0, val))
        scope[target] = val
        localStorage.setItem('powerviewer_' + target, val)
        scope.graph()
      }

      scope.setColor = (target, color) => {
        if (target === 'accent') {
            scope.uiAccentColor = color; 
            localStorage.setItem('powerviewer_uiAccentColor', color);
        } else if (target === 'hp') {
            scope.colorPower = color;
            localStorage.setItem('powerviewer_colorPower', color);
        } else if (target === 'trq') {
            scope.colorTorque = color;
            localStorage.setItem('powerviewer_colorTorque', color);
        }
        scope.graph()
      }
      scope.setAccent = (c) => scope.setColor('accent', c);

      scope.setUnit = (type, val) => {
        scope[type] = val
        localStorage.setItem('powerviewer_' + type, val)
        scope.graph()
      }

      scope.togglePeakInfo = () => {
        scope.showPeakInfo = !scope.showPeakInfo
        localStorage.setItem('powerviewer_showPeakInfo', scope.showPeakInfo)
      }

      scope.toggleRpmLine = () => {
        if (scope.showRpmLine === 'off') scope.showRpmLine = 'faded';
        else if (scope.showRpmLine === 'faded') scope.showRpmLine = 'solid';
        else scope.showRpmLine = 'off';
        localStorage.setItem('powerviewer_showRpmLine', scope.showRpmLine)
      }

      scope.togglePeakDiffMode = () => {
        if (scope.peakDiffMode === 'diff') scope.peakDiffMode = 'na';
        else if (scope.peakDiffMode === 'na') scope.peakDiffMode = 'off';
        else scope.peakDiffMode = 'diff';
        localStorage.setItem('powerviewer_peakDiffMode', scope.peakDiffMode)
      }

      scope.togglePeakLines = () => {
        scope.showPeakLines = !scope.showPeakLines
        localStorage.setItem('powerviewer_showPeakLines', scope.showPeakLines)
        scope.graph()
      }

      scope.toggleGhostPeakLines = () => {
        scope.showGhostPeakLines = !scope.showGhostPeakLines
        localStorage.setItem('powerviewer_showGhostPeakLines', scope.showGhostPeakLines)
        scope.graph()
      }

      scope.toggleSubTicks = () => {
        scope.showSubTicks = !scope.showSubTicks
        localStorage.setItem('powerviewer_showSubTicks', scope.showSubTicks)
        scope.graph()
      }

      // ANIMATED BUTTON LOGIC
      scope.startHoldBtn = (action) => {
        if (action === 'hold' && !scope.ghostData) {
            scope.saveGhost(); 
            return;
        }
        scope.holdProgress = 0;
        scope.activeBtn = action; 
        scope.holdTimer = setInterval(() => {
            scope.holdProgress += 5; 
            if (scope.holdProgress >= 100) {
                if (action === 'hold') scope.saveGhost();
                if (action === 'clear') scope.clearGhost();
                scope.endHoldBtn();
            }
            scope.$evalAsync(); 
        }, 25);
      }

      scope.endHoldBtn = () => {
        clearInterval(scope.holdTimer);
        scope.holdProgress = 0;
        scope.activeBtn = null;
        scope.$evalAsync();
      }

      scope.saveGhost = () => {
        scope.ghostData = angular.copy(scope.config);
        scope.graph();
      }

      scope.clearGhost = () => {
        scope.ghostData = null;
        scope.graph();
      }

      scope.getBtnStyle = (active) => {
        return {
          padding: '0 12px', height: '24px', display: 'flex', alignItems: 'center', 
          background: active ? scope.uiAccentColor : '#222',
          color: active ? '#000' : '#fff', cursor: 'pointer', borderRadius: '3px',
          fontSize: '11px', fontWeight: 'bold', border: '1px solid ' + (active ? '#fff' : '#444')
        }
      }

      // 3. GRAPHING SETUP
      var staticCanvas = element[0].getElementsByTagName('canvas')[0]
        , sctx = staticCanvas.getContext('2d')
        , dynamicCanvas = element[0].getElementsByTagName('canvas')[1]
        , dctx = dynamicCanvas.getContext('2d')
        , maxRpm = 1, xFactor = -1
        , torqueData = [], torqueCurve = [], powerData = [], powerCurve = []
        , torqueData_forcedInduction = [], torqueCurve_forcedInduction = [], powerData_forcedInduction = [], powerCurve_forcedInduction = []

      // This will be dynamic in plotStaticGraphs now
      var plotMargins = {top: 30, bottom: 25, left: 50, right: 50}
      var gridParams = {color: 'rgba(0,0,0,0.4)', width: 1}

      var currentVehicle = {
        id: '',
        engines: []
      }

      scope.engineIndex = -1
      scope.engines = []

      scope.selectedEngine = ''

      scope.$on('VehicleChange', () => {
        currentVehicle.id = ''
      })


      scope.$on('TorqueCurveChanged', function (_, data) {
        setTimeout(function () {
          if (data.vehicleID !== currentVehicle.id) {
            currentVehicle.id = data.vehicleID
            currentVehicle.engines = []
            scope.engines = []
            scope.engineIndex = -1
            scope.selectedEngine = ''
          }

          if (! currentVehicle.engines.find(engine => engine.name === data.deviceName)) {
            currentVehicle.engines.push({name: data.deviceName, curves: data.curves, maxRPM: data.maxRPM})
            scope.curves = data.curves
            scope.engines.push(data.deviceName)
          } 

          scope.$evalAsync(() => {
            if (scope.engineIndex < 0) {
              scope.selectEngine(0)
            }
          })
        }, 0)
      })

      scope.onEngineSelection = () => {
        var ind = scope.engines.indexOf(scope.selectedEngine)
        if (ind > -1)
          scope.selectEngine(ind)
      }

      scope.selectEngine = (engineIndex) => {
        for (var key in scope.config) {
          scope.config[key].power.data = []
          scope.config[key].power.max = 0
          scope.config[key].torque.data = []
          scope.config[key].torque.max = 0
          scope.config[key].isPresent = false
        }

        maxRpm = currentVehicle.engines[engineIndex].maxRPM
        updateScopeData(currentVehicle.engines[engineIndex].curves)
        scope.engineIndex = engineIndex
        
        scope.selectedEngine = currentVehicle.engines[engineIndex].name
        scope.engineIndex = engineIndex
        plotStaticGraphs()
        scope.$evalAsync()
      }

      scope.$on('SettingsChanged', function () {
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })

      var updateScopeData = function (curves) {
        let solidMaxP = 0, solidMaxT = 0;
        let dashedMaxP = 0, dashedMaxT = 0;
        let globalMaxP = 0, globalMaxT = 0;

        for (var key in curves) {
          var c = curves[key];
          var mp = Math.max.apply(Math, c.power);
          var mt = Math.max.apply(Math, c.torque);
          var isDashed = (c.dash && c.dash.length > 0);

          if (isDashed) { dashedMaxP = mp; dashedMaxT = mt; } 
          else {
            solidMaxP = mp; solidMaxT = mt;
            scope.peakPowerRpm = c.power.indexOf(mp);
            scope.peakTorqueRpm = c.torque.indexOf(mt);
          }

          if (mp > globalMaxP) globalMaxP = mp;
          if (mt > globalMaxT) globalMaxT = mt;

          scope.config[key] = {
            torque: { 
              color: scope.colorTorque, 
              width: c.width, 
              data: c.torque, 
              dashArray: c.dash || [], 
              isDashed: isDashed 
            },
            power: { 
              color: scope.colorPower, 
              width: c.width, 
              data: c.power, 
              dashArray: c.dash || [], 
              isDashed: isDashed 
            },
            isPresent: true,
            name: c.name
          }
        }
        scope.absMaxPower = globalMaxP;
        scope.absMaxTorque = globalMaxT;
        scope.diffPower = (dashedMaxP > 0) ? (solidMaxP - dashedMaxP) : 0;
        scope.diffTorque = (dashedMaxT > 0) ? (solidMaxT - dashedMaxT) : 0;
        scope.naMaxPower = dashedMaxP; // Added for NA Peak toggle
        scope.naMaxTorque = dashedMaxT; // Added for NA Peak toggle
      }

      var plotStaticGraphs = function () {
        staticCanvas.width = scope.appWidth;
        staticCanvas.height = scope.appHeight - 20; 
        dynamicCanvas.width = scope.appWidth;
        dynamicCanvas.height = scope.appHeight - 20;

        plotMargins.left = 10; 
        plotMargins.right = scope.sizeMain * 4; 
        plotMargins.top = 20;  
        plotMargins.bottom = scope.sizeMain * 4;

        // X-Axis Scale: MaxRPM + 1000
        var displayMaxRpm = maxRpm;
        xFactor = (staticCanvas.width - plotMargins.left - plotMargins.right) / displayMaxRpm;

        sctx.clearRect(0, 0, staticCanvas.width, staticCanvas.height);

        // 1. Unified Max Calculation
        var rawMaxP = scope.absMaxPower || 100;
        var rawMaxT = scope.absMaxTorque || 100;

        // Check Ghost Data for scaling
        if (scope.ghostData) {
             Object.keys(scope.ghostData).forEach(k => {
                 let curve = scope.ghostData[k];
                 if (curve.isPresent) {
                     if(curve.power && curve.power.data.length) rawMaxP = Math.max(rawMaxP, ...curve.power.data);
                     if(curve.torque && curve.torque.data.length) rawMaxT = Math.max(rawMaxT, ...curve.torque.data);
                 }
             });
        }

        // Apply visual multiplier for kg-m so the line isn't tiny
        var trqMult = (scope.unitTorque === 'kg-m') ? 10 : 1;
        
        // Find the absolute highest value after unit conversion and multiplier
        var unifiedMax = Math.max(scope.convertPower(rawMaxP), scope.convertTorque(rawMaxT) * trqMult);

        var getBestScale = (val) => {
            if (!val || val === 0) return { max: 100, step: 20, divs: 5 };
            let candidates = [1, 2, 5, 10, 20, 25, 40, 50, 100, 200, 250, 500, 1000, 2000, 5000];
            let best = { max: Math.ceil(val/100)*100 + 100, step: 100, divs: 5 };
            let minWaste = Infinity;
            candidates.forEach(step => {
                let divs = Math.ceil(val / step);
                let max = divs * step;
                let waste = max - val;
                if (divs >= 4 && divs <= 10) {
                     if (waste < minWaste) {
                         minWaste = waste;
                         best = { max: max, step: step, divs: divs };
                     }
                }
            });
            return best;
        }

        var scaleU = getBestScale(unifiedMax); // Unified Scale

        // --- DRAW AXES (Unified Right Side) ---
        sctx.globalAlpha = scope.valuesOpacity; 

        // Draw Vertical Line (Right Side)
        sctx.lineWidth = 1;
        sctx.beginPath();
        sctx.strokeStyle = scope.uiAccentColor;
        sctx.moveTo(staticCanvas.width - plotMargins.right, plotMargins.top);
        sctx.lineTo(staticCanvas.width - plotMargins.right, staticCanvas.height - plotMargins.bottom);
        sctx.stroke();

        let totalSubSteps = scaleU.divs * 2;
        let subStepVal = scaleU.step / 2;
        let showSubs = scope.showSubTicks && scope.appHeight > 150;

        for (let i = 0; i <= totalSubSteps; i++) {
            let isMajor = (i % 2 === 0);
            if (!isMajor && !showSubs) continue;

            let val = i * subStepVal;
            let y = (staticCanvas.height - plotMargins.bottom) - ((val / scaleU.max) * (staticCanvas.height - plotMargins.top - plotMargins.bottom));
            let x = staticCanvas.width - plotMargins.right;

            sctx.beginPath();
            sctx.strokeStyle = scope.uiAccentColor;
            sctx.moveTo(x, y);
            sctx.lineTo(x + (isMajor ? 6 : 3), y);
            sctx.stroke();

            if (isMajor || showSubs) {
                sctx.fillStyle = isMajor ? scope.uiAccentColor : scope.getAccentRgba(0.6);
                sctx.font = (isMajor ? scope.sizeMain : (scope.sizeMain * 0.8)) + "px monospace";
                sctx.textAlign = "left";
                sctx.textBaseline = "middle";
                sctx.fillText(scope.formatNum(val), x + 8, y);
            }
            
            // Draw Background Grid Lines
            if (isMajor) {
                sctx.beginPath();
                sctx.strokeStyle = scope.getAccentRgba(scope.gridOpacity);
                sctx.setLineDash([2, 4]);
                sctx.moveTo(plotMargins.left, y);
                sctx.lineTo(x, y);
                sctx.stroke();
                sctx.setLineDash([]);
            }
        }

        // Draw KG-M x10 Label (Aligned with scale numbers)
        if (scope.unitTorque === 'kg-m') {
            sctx.fillStyle = scope.colorTorque;
            sctx.font = "bold 9px monospace";
            sctx.textAlign = "left"; // Align left like the scale numbers
            
            // Position x: same as scale numbers (right edge + 8px padding)
            // Position y: just below the bottom of the vertical axis
            let labelX = staticCanvas.width - plotMargins.right + 8;
            let labelY = staticCanvas.height - plotMargins.bottom + 12;

            sctx.fillText("KG-M", labelX, labelY);
            sctx.fillText("x10", labelX, labelY + 10); // 10px line spacing
        }
        
        // --- BOTTOM AXIS & RPM GRID ---
        sctx.lineWidth = 1;
        sctx.beginPath();
        sctx.strokeStyle = scope.uiAccentColor;
        sctx.moveTo(plotMargins.left, staticCanvas.height - plotMargins.bottom);
        sctx.lineTo(staticCanvas.width - plotMargins.right, staticCanvas.height - plotMargins.bottom);
        sctx.stroke();

        // RPM Loop
        for (let r = 0; r <= displayMaxRpm; r += 500) {
            // Logic: Hide 500s if SubTicks off OR width too small
            if (!showSubs && r % 1000 !== 0) continue; 
            if (scope.appWidth < 400 && r % 1000 !== 0) continue;

            let x = plotMargins.left + (r * xFactor);
            let y = staticCanvas.height - plotMargins.bottom + 10;
            let isFullThousand = (r % 1000 === 0);
            
            // Grid Line
            if (isFullThousand || showSubs) {
                sctx.beginPath();
                sctx.strokeStyle = isFullThousand ? scope.getAccentRgba(scope.gridOpacity) : scope.getAccentRgba(scope.gridOpacity * 0.5);
                sctx.setLineDash([2, 4]);
                sctx.moveTo(x, plotMargins.top);
                sctx.lineTo(x, staticCanvas.height - plotMargins.bottom);
                sctx.stroke();
                sctx.setLineDash([]);
            }

            // Tick Mark
            sctx.beginPath();
            sctx.strokeStyle = scope.uiAccentColor;
            sctx.moveTo(x, staticCanvas.height - plotMargins.bottom);
            sctx.lineTo(x, staticCanvas.height - plotMargins.bottom + (isFullThousand ? 6 : 3));
            sctx.stroke();

            // Text
            sctx.save();
            sctx.translate(x, y);
            sctx.rotate(Math.PI / 4); 
            sctx.textAlign = "left";
            sctx.fillStyle = isFullThousand ? scope.uiAccentColor : scope.getAccentRgba(0.6);
            sctx.font = (!isFullThousand ? (scope.sizeMain * 0.8) : scope.sizeMain) + "px monospace";
            sctx.fillText(scope.formatNum(r), 0, 0);
            sctx.restore();
        }

        sctx.globalAlpha = 1.0; // <--- RESET OPACITY

        // --- CURVE DRAWER ---
        var drawCurveCustom = (dataArr, maxVal, color, width, dash, isGhost) => {
             if (!dataArr || dataArr.length < 2) return;
             
             let graphH = staticCanvas.height - plotMargins.top - plotMargins.bottom;
             let bottomY = staticCanvas.height - plotMargins.bottom;

             sctx.beginPath();
             sctx.lineWidth = width;
             sctx.strokeStyle = color;
             sctx.setLineDash(dash || []);
             sctx.lineJoin = "round";

             let started = false;

             // Just draw the real data. 
             // Since we changed displayMaxRpm, this loop will naturally reach the right edge.
             for (let r = 0; r < dataArr.length; r++) {
                 let val = dataArr[r];
                 let cx = plotMargins.left + (r * xFactor);
                 let cy = bottomY - ((val / maxVal) * graphH);

                 if (!started) {
                     sctx.moveTo(cx, cy);
                     started = true;
                 } else {
                     sctx.lineTo(cx, cy);
                 }
             }
             sctx.stroke();
             sctx.setLineDash([]);
        };

        var drawSet = (configSet, isGhost) => {
            Object.keys(configSet).forEach(function (x) {
              var cc = configSet[x];
              if (!cc.isPresent) return;
              if(cc.torque.isDashed) scope.hasDashedLines = true; 

              // Use trqMult here for the data points
              let tData = cc.torque.data.map(v => scope.convertTorque(v) * trqMult);
              let pData = cc.power.data.map(v => scope.convertPower(v));
              
              let alpha = isGhost ? scope.ghostOpacity : (cc.torque.isDashed ? scope.dashedOpacity : scope.powerOpacity);
              
              sctx.globalAlpha = alpha;
              
              // Change: Both now use scaleU.max instead of scaleT or scaleP
              drawCurveCustom(tData, scaleU.max, scope.colorTorque, cc.torque.width, cc.torque.dashArray, isGhost);
              drawCurveCustom(pData, scaleU.max, scope.colorPower, cc.power.width, cc.power.dashArray, isGhost);
            });
        };

        if (scope.ghostData) drawSet(scope.ghostData, true);
        drawSet(scope.config, false);
        
        // --- PEAK LINES ---
        // Helper function to draw lines
        var drawPeakSet = (pVal, pIdx, tVal, tIdx, opacity, isGhost) => {
            sctx.globalAlpha = opacity; 
            sctx.lineWidth = 1;
            if (isGhost) sctx.setLineDash([4, 4]); 

            let graphH = staticCanvas.height - plotMargins.top - plotMargins.bottom;
            let getY = (val, max) => (staticCanvas.height - plotMargins.bottom) - ((val / max) * graphH);

            // Power Line
            if (pIdx > 0 && pVal > 0) {
                let pRpmX = plotMargins.left + (pIdx * xFactor);
                let pY = getY(scope.convertPower(pVal), scaleU.max);
                
                sctx.strokeStyle = scope.colorPower;
                sctx.beginPath();
                sctx.moveTo(pRpmX, pY);
                sctx.lineTo(pRpmX, staticCanvas.height - plotMargins.bottom); // Down to RPM Axis
                sctx.moveTo(pRpmX, pY);
                sctx.lineTo(staticCanvas.width - plotMargins.right, pY); // Right to Scale
                sctx.stroke();
            }

            // Torque Line
            if (tIdx > 0 && tVal > 0) {
                let tRpmX = plotMargins.left + (tIdx * xFactor);
                let tY = getY(scope.convertTorque(tVal) * trqMult, scaleU.max);

                sctx.strokeStyle = scope.colorTorque;
                sctx.beginPath();
                sctx.moveTo(tRpmX, tY);
                sctx.lineTo(tRpmX, staticCanvas.height - plotMargins.bottom); // Down to RPM Axis
                sctx.moveTo(tRpmX, tY);
                sctx.lineTo(staticCanvas.width - plotMargins.right, tY); // Right to Scale
                sctx.stroke();
            }
            sctx.setLineDash([]); 
        };

        // 1. Draw CURRENT Peak Lines (If enabled)
        if (scope.showPeakLines) {
            drawPeakSet(scope.absMaxPower, scope.peakPowerRpm, scope.absMaxTorque, scope.peakTorqueRpm, scope.lineOpacity, false);
        }

        // 2. Draw GHOST Peak Lines (If enabled and ghost data exists)
        if (scope.showGhostPeakLines && scope.ghostData) {
            // We must calculate the peaks for the ghost data specifically
            let gMaxP = 0, gIdxP = 0;
            let gMaxT = 0, gIdxT = 0;

            Object.keys(scope.ghostData).forEach(k => {
                let c = scope.ghostData[k];
                if (c.isPresent) {
                    if (c.power && c.power.data) {
                        let mp = Math.max(...c.power.data);
                        if (mp > gMaxP) { gMaxP = mp; gIdxP = c.power.data.indexOf(mp); }
                    }
                    if (c.torque && c.torque.data) {
                        let mt = Math.max(...c.torque.data);
                        if (mt > gMaxT) { gMaxT = mt; gIdxT = c.torque.data.indexOf(mt); }
                    }
                }
            });

            // Draw them slightly fainter (combine lineOpacity * ghostOpacity)
            drawPeakSet(gMaxP, gIdxP, gMaxT, gIdxT, scope.lineOpacity * scope.ghostOpacity, true);
        }

        sctx.globalAlpha = 1.0;

        scope.graph = plotStaticGraphs;
      }

      scope.graph = plotStaticGraphs;

      scope.$on('streamsUpdate', function (event, streams) {
        if (scope.appMode === 'launcher') return;
        
        dctx.clearRect(0, 0, dynamicCanvas.width, dynamicCanvas.height)
        
        // 1. Check if feature is enabled or data is missing
        if (scope.showRpmLine === 'off' || !streams.engineInfo) return;
        
        var _rpm = streams.engineInfo[4]
        
        // Clamp the RPM to the graph limit.
        var effectiveRpm = Math.min(_rpm, maxRpm);

        // 2. Calculate X Position based on the CLAMPED value
        var rpmX = plotMargins.left + Math.floor(effectiveRpm * xFactor)

        // 3. Draw the Line
        dctx.beginPath()
        dctx.moveTo(rpmX, plotMargins.top)
        dctx.lineTo(rpmX, dynamicCanvas.height - plotMargins.bottom)

        dctx.lineWidth = 2
        
        // --- GRADIENT LOGIC ---
        var grad = dctx.createLinearGradient(0, plotMargins.top, 0, dynamicCanvas.height - plotMargins.bottom);
        
        if (scope.showRpmLine === 'solid') {
             // Solid Line (Uniform color)
             grad.addColorStop(0, scope.uiAccentColor);
             grad.addColorStop(1, scope.uiAccentColor);
        } else {
             // Faded Line (Original)
             grad.addColorStop(0, "rgba(0,0,0,0)"); // Fade out completely at top
             grad.addColorStop(0.3, scope.uiAccentColor); // Full color at 30% down
             grad.addColorStop(1, scope.uiAccentColor);
        }

        dctx.strokeStyle = grad
        dctx.shadowBlur = 30
        dctx.shadowColor = 'steelblue'
        dctx.stroke()
      })

      var _ready = false

      scope.$on('app:resized', function (event, data) {
        // We can use this event as initialization trigger since it is emitted from
        // the app-container for this reason
        staticCanvas.width = element[0].clientWidth
        staticCanvas.height = element[0].clientHeight
        dynamicCanvas.width = element[0].clientWidth
        dynamicCanvas.height = element[0].clientHeight

        if (!_ready) {
          _ready = true
          bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
        } else {
          plotStaticGraphs()
        }
      })

      scope.$on('VehicleFocusChanged', function() {
        bngApi.activeObjectLua('controller.mainController.sendTorqueData()')
      })

    }
  }
}]);