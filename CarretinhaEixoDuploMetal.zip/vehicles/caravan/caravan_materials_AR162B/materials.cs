singleton Material(caravan_sunscreen_metal)
{
    mapTo = "caravan_sunscreen_metal";
    diffuseMap[1] = "vehicles/caravan/caravan_materials_AR162B/caravan_metal_D.dds";
    specularMap[1] = "vehicles/caravan/caravan_materials_AR162B/caravan_metal_S.dds";
    normalMap[1] = "vehicles/common/null_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[1] = "vehicles/common/null_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(caravan_sunscreen_fabric)
{
    mapTo = "caravan_sunscreen_fabric";
    diffuseMap[1] = "vehicles/caravan/caravan_materials_AR162B/caravan_fabric_D.dds";
    specularMap[1] = "vehicles/caravan/caravan_materials_AR162B/caravan_fabric_S.dds";
    normalMap[1] = "vehicles/common/null_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[1] = "vehicles/common/null_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};