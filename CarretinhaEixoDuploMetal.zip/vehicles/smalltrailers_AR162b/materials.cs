singleton Material(tr_haybale)
{
    mapTo = "haybale";
    diffuseMap[0] = "vehicles/haybale/haybale_d.dds";
    specularMap[0] = "vehicles/haybale/haybale_s.dds";
    normalMap[0] = "vehicles/haybale/haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(tr_haybale2)
{
    mapTo = "haybale2";
    diffuseMap[0] = "vehicles/haybale/haybale2_d.dds";
    specularMap[0] = "vehicles/haybale/haybale_s.dds";
    normalMap[0] = "vehicles/haybale/haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    //subSurface[0] = "1";
    //subSurfaceColor[0] = "0.996078 0.992157 0.992157 1";
    //subSurfaceRolloff[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(tr_haybale3)
{
    mapTo = "haybale3";
    diffuseMap[0] = "vehicles/haybale/haybale3_d.dds";
    specularMap[0] = "vehicles/haybale/haybale_s.dds";
    normalMap[0] = "vehicles/haybale/haybale_n.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    diffuseColor[0] = "1 1 1 1";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "1";
    alphaRef = "64";
    subSurface[0] = "1";
    subSurfaceColor[0] = "0.996078 0.992157 0.992157 1";
    subSurfaceRolloff[0] = "0.4";
    materialTag0 = "beamng"; materialTag1 = "object";
    doubleSided = "1";
};

singleton Material(trailer_metal_box)
{
    mapTo = "trailer_metal_box";
    diffuseMap[1] = "vehicles/metal_box/metal_box_D.dds";
    specularMap[1] = "vehicles/metal_box/metal_box_S.dds";
    normalMap[1] = "vehicles/metal_box/metal_box_N.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/metal_box/metal_box_N.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "object";
};

singleton Material(trailer_metal_box_decals)
{
    mapTo = "trailer_metal_box_decals";
    diffuseMap[1] = "vehicles/metal_box/metal_box_decals.dds";
    specularMap[1] = "vehicles/common/null.dds";
    specularPower[0] = "16";
    pixelSpecular[0] = "1";
    specularPower[1] = "16";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "0 0 0 0";
    diffuseColor[1] = "1 1 1 0.6";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "0";
    translucent = "1";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
    materialTag0 = "beamng"; materialTag1 = "vehicle"; materialTag2 = "decal";
    translucentZWrite = "1";
};

singleton Material(tsfb)
{
    mapTo = "tsfb";
    diffuseMap[1] = "vehicles/tsfb/tsfb_d.dds";
    specularMap[1] = "vehicles/tsfb/tsfb_s.dds";
    normalMap[1] = "vehicles/tsfb/tsfb_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/tsfb/tsfb_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true; //cubemap = "BNG_Sky_02_cubemap";
};
singleton Material(AR162B_caravan)
{
    mapTo = "caravan";
    diffuseMap[1] = "vehicles/caravan/caravan_d.dds";
    specularMap[1] = "vehicles/caravan/caravan_s.dds";
    normalMap[1] = "vehicles/caravan/caravan_n.dds";
    diffuseMap[0] = "vehicles/common/null.dds";
    specularMap[0] = "vehicles/common/null.dds";
    normalMap[0] = "vehicles/caravan/caravan_n.dds";
    specularPower[0] = "128";
    pixelSpecular[0] = "1";
    specularPower[1] = "32";
    pixelSpecular[1] = "1";
    diffuseColor[0] = "1 1 1 1";
    diffuseColor[1] = "1 1 1 1";
    useAnisotropic[0] = "1";
    useAnisotropic[1] = "1";
    castShadows = "1";
    translucent = "1";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};